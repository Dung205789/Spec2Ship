# Ticket Examples

1. Fix failing tests in discount calculation.
2. Add a /health endpoint for smoke tests.
