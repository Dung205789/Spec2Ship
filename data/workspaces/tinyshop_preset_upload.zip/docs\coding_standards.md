# Coding Standards

- Prefer small, focused functions.
- Validate inputs and clamp ranges where needed.
- For money calculations, be explicit about rounding rules.
